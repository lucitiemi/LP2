﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVestibular
{
    public partial class Vestibular : Form
    {
        int totalCurso, totalGeral = 0;
        int[] vetorTotalCurso = new int[2];

        public Vestibular()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResult.Items.Clear();
        }

        private void btnReceber_Click(object sender, EventArgs e)
        {
            int[,] matriz = new int[2, 5];
            string aux = "";
            


            for (int i = 0; i < 2; i++)
            {
                totalCurso = 0;

                for (int j = 0; j < 5; j++)
                {
                    aux = Interaction.InputBox($"Digite a quantidade de alunos do curso {i + 1}, no ano {j + 1}: ", "Entrada de Dados");


                    if (!int.TryParse(aux, out matriz[i, j]))
                    {
                        MessageBox.Show("Valor inválido");
                        j--;
                    }
                    else
                    {
                        totalCurso += matriz[i, j];
                        totalGeral += matriz[i, j];
                    }

                    vetorTotalCurso[i] = totalCurso;    
             
                }

            }
            //MessageBox.Show(matriz[0, 0].ToString());
            //MessageBox.Show(matriz[1, 0].ToString());

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 5; j++)
                {
 
                    lstbxResult.Items.Add($"Total do curso {i+1} do Ano {j+1}: {matriz[i,j]}");
                    
                }
                lstbxResult.Items.Add("-------------------------------");
                lstbxResult.Items.Add($"Total curso {i+1}: {vetorTotalCurso[i]}");
            }

            lstbxResult.Items.Add("-------------------------------");
            lstbxResult.Items.Add($"Total geral: {totalGeral}");
        }
    }

}
