﻿namespace PVestibular
{
    partial class Vestibular
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReceber = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lstbxResult = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnReceber
            // 
            this.btnReceber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnReceber.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReceber.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReceber.ForeColor = System.Drawing.Color.Lime;
            this.btnReceber.Location = new System.Drawing.Point(87, 58);
            this.btnReceber.Name = "btnReceber";
            this.btnReceber.Size = new System.Drawing.Size(182, 104);
            this.btnReceber.TabIndex = 0;
            this.btnReceber.Text = "Receber Dados";
            this.btnReceber.UseVisualStyleBackColor = false;
            this.btnReceber.Click += new System.EventHandler(this.btnReceber_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnLimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.Lime;
            this.btnLimpar.Location = new System.Drawing.Point(87, 270);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(182, 112);
            this.btnLimpar.TabIndex = 1;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lstbxResult
            // 
            this.lstbxResult.BackColor = System.Drawing.Color.Black;
            this.lstbxResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstbxResult.ForeColor = System.Drawing.Color.LimeGreen;
            this.lstbxResult.FormattingEnabled = true;
            this.lstbxResult.ItemHeight = 20;
            this.lstbxResult.Location = new System.Drawing.Point(351, 58);
            this.lstbxResult.Name = "lstbxResult";
            this.lstbxResult.Size = new System.Drawing.Size(303, 324);
            this.lstbxResult.TabIndex = 2;
            // 
            // Vestibular
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(720, 450);
            this.Controls.Add(this.lstbxResult);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnReceber);
            this.Name = "Vestibular";
            this.Text = "Vestibular";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnReceber;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.ListBox lstbxResult;
    }
}

