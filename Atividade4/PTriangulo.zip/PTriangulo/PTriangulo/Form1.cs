﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;


        public Form1()
        {
            InitializeComponent();
        }



        //VALIDANDO LADO A
        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtLadoA.Text, out ladoA)) || (ladoA <= 0))
            {
                MessageBox.Show("Valor inválido");
                txtLadoA.Focus();
            }
        }


        //VALIDANDO LADO B
        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtLadoB.Text, out ladoB)) || (ladoB <= 0))
            {
                MessageBox.Show("Valor inválido");
                txtLadoB.Focus();
            }
        }


        //VALIDANDO LADO C
        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtLadoC.Text, out ladoC)) || (ladoC <= 0))
            {
                MessageBox.Show("Valor inválido");
                txtLadoC.Focus();
            }
        }


        //BOTAO VERIFICAR
        private void btnVerif_Click(object sender, EventArgs e)
        {

            if (((Math.Abs(ladoB))-(Math.Abs(ladoC))<ladoA && ladoA<(ladoB+ladoC)) && 
                ((Math.Abs(ladoA))-(Math.Abs(ladoC))<ladoB && ladoB<(ladoA+ladoC)) && 
                ((Math.Abs(ladoA))-(Math.Abs(ladoB))<ladoC && ladoC<(ladoA+ladoB)))
            {
                if ((ladoA == ladoB) && (ladoA == ladoC))
                    MessageBox.Show("Triângulo equilátero");
                else
                if (((ladoA == ladoB) && (ladoA != ladoC)) || ((ladoA == ladoC) && (ladoA != ladoB)))
                    MessageBox.Show("Triângulo isósceles");
                else
                    MessageBox.Show("Triângulo escaleno");
            }
            else
            {
                MessageBox.Show("Não é um triângulo! Digite novamente as medidas.");
                txtLadoA.Focus();
            }
                

        }

        //BOTAO SAIR
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();    
        }





    }
}
