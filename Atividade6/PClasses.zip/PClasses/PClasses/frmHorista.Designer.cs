﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciar1 = new System.Windows.Forms.Button();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.lblData = new System.Windows.Forms.Label();
            this.txtSalHoras = new System.Windows.Forms.TextBox();
            this.lblSalHoras = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblHorasTrab = new System.Windows.Forms.Label();
            this.txtHorasTrab = new System.Windows.Forms.TextBox();
            this.lblFaltas = new System.Windows.Forms.Label();
            this.txtFaltas = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnInstanciar1
            // 
            this.btnInstanciar1.Location = new System.Drawing.Point(34, 321);
            this.btnInstanciar1.Name = "btnInstanciar1";
            this.btnInstanciar1.Size = new System.Drawing.Size(150, 49);
            this.btnInstanciar1.TabIndex = 21;
            this.btnInstanciar1.Text = "Instanciar Horista";
            this.btnInstanciar1.UseVisualStyleBackColor = true;
            this.btnInstanciar1.Click += new System.EventHandler(this.btnInstanciar1_Click);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(196, 79);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(344, 20);
            this.txtNome.TabIndex = 12;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(32, 82);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 11;
            this.lblNome.Text = "Nome";
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(196, 180);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(192, 20);
            this.txtData.TabIndex = 16;
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(32, 183);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(129, 13);
            this.lblData.TabIndex = 15;
            this.lblData.Text = "Data Entrada na Empresa";
            // 
            // txtSalHoras
            // 
            this.txtSalHoras.Location = new System.Drawing.Point(196, 128);
            this.txtSalHoras.Name = "txtSalHoras";
            this.txtSalHoras.Size = new System.Drawing.Size(192, 20);
            this.txtSalHoras.TabIndex = 14;
            // 
            // lblSalHoras
            // 
            this.lblSalHoras.AutoSize = true;
            this.lblSalHoras.Location = new System.Drawing.Point(32, 131);
            this.lblSalHoras.Name = "lblSalHoras";
            this.lblSalHoras.Size = new System.Drawing.Size(83, 13);
            this.lblSalHoras.TabIndex = 13;
            this.lblSalHoras.Text = "Salário por Hora";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(196, 36);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(192, 20);
            this.txtMatricula.TabIndex = 10;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(32, 39);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(52, 13);
            this.lblMatricula.TabIndex = 7;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblHorasTrab
            // 
            this.lblHorasTrab.AutoSize = true;
            this.lblHorasTrab.Location = new System.Drawing.Point(31, 231);
            this.lblHorasTrab.Name = "lblHorasTrab";
            this.lblHorasTrab.Size = new System.Drawing.Size(97, 13);
            this.lblHorasTrab.TabIndex = 17;
            this.lblHorasTrab.Text = "Horas Trabalhadas";
            // 
            // txtHorasTrab
            // 
            this.txtHorasTrab.Location = new System.Drawing.Point(195, 228);
            this.txtHorasTrab.Name = "txtHorasTrab";
            this.txtHorasTrab.Size = new System.Drawing.Size(192, 20);
            this.txtHorasTrab.TabIndex = 18;
            // 
            // lblFaltas
            // 
            this.lblFaltas.AutoSize = true;
            this.lblFaltas.Location = new System.Drawing.Point(31, 273);
            this.lblFaltas.Name = "lblFaltas";
            this.lblFaltas.Size = new System.Drawing.Size(35, 13);
            this.lblFaltas.TabIndex = 19;
            this.lblFaltas.Text = "Faltas";
            // 
            // txtFaltas
            // 
            this.txtFaltas.Location = new System.Drawing.Point(195, 270);
            this.txtFaltas.Name = "txtFaltas";
            this.txtFaltas.Size = new System.Drawing.Size(192, 20);
            this.txtFaltas.TabIndex = 20;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInstanciar1);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtFaltas);
            this.Controls.Add(this.lblFaltas);
            this.Controls.Add(this.txtHorasTrab);
            this.Controls.Add(this.lblHorasTrab);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.txtSalHoras);
            this.Controls.Add(this.lblSalHoras);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnInstanciar1;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.TextBox txtSalHoras;
        private System.Windows.Forms.Label lblSalHoras;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblHorasTrab;
        private System.Windows.Forms.TextBox txtHorasTrab;
        private System.Windows.Forms.Label lblFaltas;
        private System.Windows.Forms.TextBox txtFaltas;
    }
}