﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    internal class Mensalista : Empregado          
    {
        // CRIANDO AS PROPRIEDADES:
        public double SalarioMensal { get; set; } // propriedade

        

        // CRIANDO OS MÉTODOS:
        public override double SalarioBruto() // reescrevendo o método salario bruto (citado na classe empregado)
        {
            return SalarioMensal;
        }

        // CRIANDO CONSTRUTORES:
        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("aqui é mensalista"); // esse eh só para mostrar que quando aperta o botao e nao passa nenhum parametro, o programa vai passar por esse contrutor
        }

        public Mensalista(int matx, string nomex, DateTime datax, double salx)  // sobrecarga
        { 
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }

        public static String Empresa = "Toyota";
        public const String Filial = "Filial Sorocaba";  // const e static dao no mesmo
    }
}
